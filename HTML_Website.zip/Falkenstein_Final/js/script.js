﻿window.onload = function () {
    // 🎵 Background Music Control (Play/Pause)
    const backgroundMusic = document.getElementById('bg-audio');
    const audioControlButton = document.getElementById('toggle-audio');

    if (backgroundMusic && audioControlButton) {
        // Initially, the button will display "Play Music" until clicked.
        audioControlButton.addEventListener('click', () => {
            if (backgroundMusic.paused) {
                backgroundMusic.play().then(() => {
                    audioControlButton.textContent = 'Pause Music';
                }).catch((e) => {
                    console.error('Error playing audio:', e);
                    audioControlButton.textContent = 'Error playing audio';
                });
            } else {
                backgroundMusic.pause();
                audioControlButton.textContent = 'Play Music';
            }
        });
    }

    // Theme Toggle
    const toggleButton = document.getElementById('toggle-theme');
    if (toggleButton) {
        toggleButton.addEventListener('click', () => {
            document.body.classList.toggle('dark');
            document.body.classList.toggle('light');
        });
    }


    // Mood Tracker
    const moodSelect = document.getElementById('mood-select');
    const moodResponse = document.getElementById('mood-response');

    if (moodSelect && moodResponse) {
        moodSelect.addEventListener('change', () => {
            const mood = moodSelect.value;
            localStorage.setItem('userMood', mood);
            let message = '';
            switch (mood) {
                case 'happy':
                    message = "That's wonderful! Keep spreading positivity 🌞";
                    break;
                case 'neutral':
                    message = "A balanced day. Stay grounded and mindful.";
                    break;
                case 'sad':
                    message = "It's okay to feel this way. Be gentle with yourself 💙";
                    break;
                case 'anxious':
                    message = "Take a deep breath. You're doing your best 🫶";
                    break;
                default:
                    message = "";
            }
            moodResponse.textContent = message;
        });
    }

    // Breathing Exercise
    const breathingCircle = document.getElementById('breathing-circle');
    const breathingInstruction = document.getElementById('breathing-instruction');
    const startBreathingBtn = document.getElementById('start-breathing');

    if (startBreathingBtn && breathingCircle && breathingInstruction) {
        startBreathingBtn.addEventListener('click', () => {
            let cycle = 0;
            breathingInstruction.textContent = "Breathe In...";
            breathingCircle.classList.add('breathe-in');

            const interval = setInterval(() => {
                cycle++;
                if (cycle % 2 === 1) {
                    breathingInstruction.textContent = "Breathe Out...";
                    breathingCircle.classList.remove('breathe-in');
                    breathingCircle.classList.add('breathe-out');
                } else {
                    breathingInstruction.textContent = "Breathe In...";
                    breathingCircle.classList.remove('breathe-out');
                    breathingCircle.classList.add('breathe-in');
                }

                if (cycle === 6) {
                    clearInterval(interval);
                    breathingInstruction.textContent = "Good job! You've completed a cycle.";
                    breathingCircle.classList.remove('breathe-in', 'breathe-out');
                }
            }, 4000);
        });
    }

    // Quick Check-in Quiz
    const checkinForm = document.getElementById('checkin-form');
    const quizResponse = document.getElementById('quiz-response');

    if (checkinForm && quizResponse) {
        checkinForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const drained = checkinForm.elements['drained'].value;
            const sleep = checkinForm.elements['sleep'].value;
            const support = checkinForm.elements['support'].value;

            let score = 0;
            if (drained === 'yes') score++;
            if (sleep === 'no') score++;
            if (support === 'no') score++;

            let message = '';
            if (score === 0) {
                message = "You're doing well — keep nurturing your wellness! 🌟";
            } else if (score === 1) {
                message = "You may need a little check-in time today. Try a break or talk to someone you trust.";
            } else {
                message = "You're not alone. Please reach out — support is here for you 💙";
            }

            quizResponse.textContent = message;
        });
    }
};
