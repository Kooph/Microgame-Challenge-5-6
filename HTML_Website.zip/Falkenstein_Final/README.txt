Audio in submission video was not captured (OBS issue). However it is fully functional and can be tested by you.


About the project:
A site made for the sake of promoting Mental Health Awareness (as it's almost May). The site has ambience music that can be played on the home page, self care tools like a mood tracker and breathing exercise, as well as hotlines and other resources in case of emergency. There is also some quick quizzes and an option to toggle light/dark mode.